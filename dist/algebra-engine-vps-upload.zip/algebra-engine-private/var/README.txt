SQLite database location. Keep this folder outside the web root, owned by the PHP-FPM user (nginx) and not readable by others.
