SQLite database location. Keep this folder outside public_html and writable only by your account.
